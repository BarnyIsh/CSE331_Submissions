import * as assert from 'assert';
import * as httpMocks from 'node-mocks-http';
import { list, load, resetfilesForTesting, save } from './routes';


describe('routes', function() {
  it('save', function() {
    // First branch, straight line code, error case (only one possible input)
    const req1 = httpMocks.createRequest(
        {method: 'POST', url: '/save', body: {value: "some stuff"}});
    const res1 = httpMocks.createResponse();
    save(req1, res1);

    assert.strictEqual(res1._getStatusCode(), 400);
    assert.deepStrictEqual(res1._getData(),
        'required argument "name" was missing');

    // Second branch, straight line code, error case (only one possible input)
    const req2 = httpMocks.createRequest(
        {method: 'POST', url: '/save', body: {name: "A"}});
    const res2 = httpMocks.createResponse();
    save(req2, res2);

    assert.strictEqual(res2._getStatusCode(), 400);
    assert.deepStrictEqual(res2._getData(),
        'required argument "value" was missing');

    // Third branch, straight line code

    const req3 = httpMocks.createRequest({method: 'POST', url: '/save',
        body: {name: "A", value: "some stuff"}});
    const res3 = httpMocks.createResponse();
    save(req3, res3);

    assert.strictEqual(res3._getStatusCode(), 200);
    assert.deepStrictEqual(res3._getData(), {replaced: false});

    const req4 = httpMocks.createRequest({method: 'POST', url: '/save',
        body: {name: "A", value: "different stuff"}});
    const res4 = httpMocks.createResponse();
    save(req4, res4);

    assert.strictEqual(res4._getStatusCode(), 200);
    assert.deepStrictEqual(res4._getData(), {replaced: true});

    // Called to clear all saved files created in this test
    //    to not effect future tests
    resetfilesForTesting();
  });

  it('load', function() {

    // Requested data is in the file
    // First need to save something in order to load it
    const saveReq = httpMocks.createRequest({method: 'POST', url: '/save',
        body: {name: "a", value: "file value"}});
    const saveResp = httpMocks.createResponse();
    save(saveReq, saveResp);
    // Now we can actually (mock a) request to load the file
    const loadReq = httpMocks.createRequest(
        {method: 'GET', url: '/load', query: {name: "a"}});
    const loadRes = httpMocks.createResponse();
    load(loadReq, loadRes);
    // Validate that both the status code and the output is as expected
    assert.strictEqual(loadRes._getStatusCode(), 200);
    assert.deepStrictEqual(loadRes._getData(), {value: "file value"});

    // First need to save something in order to load it
    const saveReq1 = httpMocks.createRequest({method: 'POST', url: '/save',
        body: {name: "b", value: "val"}});
    const saveResp1 = httpMocks.createResponse();
    save(saveReq1, saveResp1);
    // Now we can actually (mock a) request to load the file
    const loadReq1 = httpMocks.createRequest(
        {method: 'GET', url: '/load', query: {name: "b"}});
    const loadRes1 = httpMocks.createResponse();
    load(loadReq1, loadRes1);
    // Validate that both the status code and the output is as expected
    assert.strictEqual(loadRes1._getStatusCode(), 200);
    assert.deepStrictEqual(loadRes1._getData(), {value: "val"});


    // Requested data is not in the file
    // First need to save something in order to load it
    const saveReq2 = httpMocks.createRequest({method: 'POST', url: '/save',
        body: {name: "keystone", value: "file value"}});
    const saveResp2 = httpMocks.createResponse();
    save(saveReq2, saveResp2);
    // Now we can actually (mock a) request to load the file
    const loadReq2 = httpMocks.createRequest(
        {method: 'GET', url: '/load', query: {name: "c"}});
    const loadRes2 = httpMocks.createResponse();
    load(loadReq2, loadRes2);
    // Validate that both the status code and the output is as expected
    assert.strictEqual(loadRes2._getStatusCode(), 404);
    assert.deepStrictEqual(loadRes2._getData(), 'file lacks inputted "name"');

    // First need to save something in order to load it
    const saveReq3 = httpMocks.createRequest({method: 'POST', url: '/save',
        body: {name: "Conrad", value: "Is a cool guy"}});
    const saveResp3 = httpMocks.createResponse();
    save(saveReq3, saveResp3);
    // Now we can actually (mock a) request to load the file
    const loadReq3 = httpMocks.createRequest(
        {method: 'GET', url: '/load', query: {name: "d"}});
    const loadRes3 = httpMocks.createResponse();
    load(loadReq3, loadRes3);
    // Validate that both the status code and the output is as expected
    assert.strictEqual(loadRes3._getStatusCode(), 404);
    assert.deepStrictEqual(loadRes3._getData(), 'file lacks inputted "name"');

    // No data was requested -> type was undefined
    // First need to save something in order to load it
    const saveReq4 = httpMocks.createRequest({method: 'POST', url: '/save',
        body: {name: "false", value: "file value"}});
    const saveResp4 = httpMocks.createResponse();
    save(saveReq4, saveResp4);
    // Now we can actually (mock a) request to load the file
    const loadReq4 = httpMocks.createRequest(
        {method: 'GET', url: '/load', query: {}});
    const loadRes4 = httpMocks.createResponse();
    load(loadReq4, loadRes4);
    // Validate that both the status code and the output is as expected
    assert.strictEqual(loadRes4._getStatusCode(), 400);
    assert.deepStrictEqual(loadRes4._getData(), 'Required argument "name" was missing');

    resetfilesForTesting();
  });
  it('list', function() {
    // Making a request without anything in the file
    const listreq = httpMocks.createRequest();
    const listresp = httpMocks.createResponse();
    list(listreq, listresp);
    // Validate that both the status code and the output is as expected
    assert.strictEqual(listresp._getStatusCode(), 200);
    assert.deepStrictEqual(listresp._getData(), {list: []});

    // Requested data is in the file
    // First need to save something in order to load it
    const saveReq1 = httpMocks.createRequest({method: 'POST', url: '/save',
        body: {name: "a", value: "file value"}});
    const saveResp1 = httpMocks.createResponse();
    save(saveReq1, saveResp1);
    // Now we can actually (mock a) request to load the file
    const listreq1 = httpMocks.createRequest();
    const listresp1 = httpMocks.createResponse();
    list(listreq1, listresp1);
    // Validate that both the status code and the output is as expected
    assert.strictEqual(listresp1._getStatusCode(), 200);
    assert.deepStrictEqual(listresp1._getData(), {list: ["a"]});
    
    resetfilesForTesting();

    // Requested data is in the file
    // First need to save something in order to load it
    const saveReq2 = httpMocks.createRequest({method: 'POST', url: '/save',
        body: {name: "a", value: "file value"}});
    const saveResp2 = httpMocks.createResponse();
    save(saveReq2, saveResp2);

    const saveReq3 = httpMocks.createRequest({method: 'POST', url: '/save',
        body: {name: "b", value: "file value"}});
    const saveResp3 = httpMocks.createResponse();
    save(saveReq3, saveResp3);

    // Now we can actually (mock a) request to load the file
    const listreq2 = httpMocks.createRequest();
    const listresp2 = httpMocks.createResponse();
    list(listreq2, listresp2);
    // Validate that both the status code and the output is as expected
    assert.strictEqual(listresp2._getStatusCode(), 200);
    assert.deepStrictEqual(listresp2._getData(), {list: ["a", "b"]});
    
    resetfilesForTesting(); 
  })
});
