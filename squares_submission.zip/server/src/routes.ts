import { Request, Response } from "express";
import { ParamsDictionary } from "express-serve-static-core";


// Require type checking of request body.
type SafeRequest = Request<ParamsDictionary, {}, Record<string, unknown>>;
type SafeResponse = Response;  // only writing, so no need to check
// Keep track of saved files. (We don't need to interpret the content of
// the file, so we can leave it as type "unknown".)
const files: Map<string, unknown> = new Map<string, unknown>();

/** Handles request for /save by storing the given file. */
export const save = (req: SafeRequest, res: SafeResponse): void => {
  const name = req.body.name;
  if (name === undefined || typeof name !== 'string') {
    res.status(400).send('required argument "name" was missing');
    return;
  }

  const value = req.body.value;
  if (value === undefined) {
    res.status(400).send('required argument "value" was missing');
    return;
  }
  console.log("save: " + name);
  console.log(value);
  res.send({replaced: files.has(name)});
  files.set(name, value);
};

/** Handles request for /load by returning the file requested. */
export const load = (req: SafeRequest, res: SafeResponse): void => {
  const name = first(req.query.name);
  if (name === undefined) {
    res.status(400).send('Required argument "name" was missing');
    return;
  } else if (!files.has(name)) {
    res.status(404).send('file lacks inputted "name"');
    return;
  } else {
    res.send({value: files.get(name)});
  }
  console.log("load: " + name);
  console.log(files.get(name));
};

/** Handles request for /list by returning the names of all files currently saved */
export const list = (_req: SafeRequest, res: SafeResponse): void => {
  res.send({list: Array.from(files.keys())});
}

// Helper to return the (first) value of the parameter if any was given.
// (This is mildly annoying because the client can also give mutiple values,
// in which case, express puts them into an array.)
const first = (param: unknown): string|undefined => {
  if (Array.isArray(param)) {
    return first(param[0]);
  } else if (typeof param === 'string') {
    return param;
  } else {
    return undefined;
  }
};

/** Used in tests to set the files map back to empty. */
export const resetfilesForTesting = (): void => {
  // Do not use this function except in tests!
  files.clear();
};