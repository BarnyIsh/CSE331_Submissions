import * as assert from 'assert';
import { solid, split, toJson, fromJson, Square, Path, findSquare, replace } from './square';
import { nil } from './list';


describe('square', function() {

  it('toJson', function() {
    assert.deepEqual(toJson(solid("white")), "white");
    assert.deepEqual(toJson(solid("green")), "green");

    const s1 = split(solid("blue"), solid("orange"), solid("purple"), solid("white"));
    assert.deepEqual(toJson(s1),
      ["blue", "orange", "purple", "white"]);

    const s2 = split(s1, solid("green"), s1, solid("red"));
    assert.deepEqual(toJson(s2),
      [["blue", "orange", "purple", "white"], "green",
       ["blue", "orange", "purple", "white"], "red"]);

    const s3 = split(solid("green"), s1, solid("yellow"), s1);
    assert.deepEqual(toJson(s3),
      ["green", ["blue", "orange", "purple", "white"],
       "yellow", ["blue", "orange", "purple", "white"]]);
  });

  it('fromJson', function() {
    assert.deepEqual(fromJson("white"), solid("white"));
    assert.deepEqual(fromJson("green"), solid("green"));

    const s1 = split(solid("blue"), solid("orange"), solid("purple"), solid("white"));
    assert.deepEqual(fromJson(["blue", "orange", "purple", "white"]), s1);

    assert.deepEqual(
        fromJson([["blue", "orange", "purple", "white"], "green",
                 ["blue", "orange", "purple", "white"], "red"]),
        split(s1, solid("green"), s1, solid("red")));

    assert.deepEqual(
        fromJson(["green", ["blue", "orange", "purple", "white"],
                  "yellow", ["blue", "orange", "purple", "white"]]),
        split(solid("green"), s1, solid("yellow"), s1));
  });
  it('findSquare', function() {
    // Creating the square and the paths to test on
    const square: Square = {kind: "split", 
    nw: {kind: "solid", color: "red"},
    ne: {kind: "solid", color: "green"},
    sw: {kind: "solid", color: "blue"},
    se: {kind: "split", 
    nw: {kind: "solid", color: "red"},
    ne: {kind: "solid", color: "green"},
    sw: {kind: "solid", color: "blue"}, 
    se: {kind: "solid", color: "white"}}}
    
    const path: Path = {kind: "nil"}
    const path1: Path = {kind: "cons", hd: "NW", tl: nil}
    const path2: Path = {kind: "cons", hd: "NE", tl: nil}
    const path3: Path = {kind: "cons", hd: "SW", tl: nil}
    const path4: Path = {kind: "cons", hd: "SE", tl: nil}
    const path5: Path = {kind: "cons", hd: "SE", tl: {kind: "cons", hd: "NW", tl: nil}}
    const path6: Path = {kind: "cons", hd: "NE", tl: {kind: "cons", hd: "NW", tl: nil}}


    // Path is not valid:
    assert.throws(() => findSquare(square, path6), Error);

    // Path is null
    assert.deepStrictEqual(findSquare(square, path), square);

    // Path is of length 1
    assert.deepStrictEqual(findSquare(square, path1), {kind: "solid", color: "red"});
    assert.deepStrictEqual(findSquare(square, path2), {kind: "solid", color: "green"});
    assert.deepStrictEqual(findSquare(square, path3), {kind: "solid", color: "blue"});
    assert.deepStrictEqual(findSquare(square, path4), square.se);

    // Path is of length greater than 1
    assert.deepStrictEqual(findSquare(square, path5), {kind: "solid", color: "red"});
  });

  it('replace', function() {
    // Creating the square and the paths to test on
    const square: Square = {kind: "split", 
    nw: {kind: "solid", color: "red"},
    ne: {kind: "solid", color: "green"},
    sw: {kind: "solid", color: "blue"},
    se: {kind: "split", 
    nw: {kind: "solid", color: "red"},
    ne: {kind: "solid", color: "green"},
    sw: {kind: "solid", color: "blue"}, 
    se: {kind: "solid", color: "white"}}}

    const path: Path = {kind: "nil"}
    const path1: Path = {kind: "cons", hd: "NW", tl: nil}
    const path2: Path = {kind: "cons", hd: "NE", tl: nil}
    const path3: Path = {kind: "cons", hd: "SW", tl: nil}
    const path4: Path = {kind: "cons", hd: "SE", tl: nil}
    const path5: Path = {kind: "cons", hd: "SE", tl: {kind: "cons", hd: "NW", tl: nil}}
    const path6: Path = {kind: "cons", hd: "NE", tl: {kind: "cons", hd: "NW", tl: nil}}

    // Replacement Square
    const replacement: Square = {kind: "split", 
    nw: {kind: "solid", color: "red"},
    ne: {kind: "solid", color: "green"},
    sw: {kind: "solid", color: "blue"},
    se: {kind: "solid", color: "white"}}


    // Path is not valid:
    assert.throws(() => replace(square, replacement, path6), Error);

    // Path is null
    assert.deepStrictEqual(replace(square, replacement, path), replacement);

    // Path is of length 1
    assert.deepStrictEqual(replace(square, replacement, path1), 
    {kind: "split", 
    nw: {kind: "split", 
    nw: {kind: "solid", color: "red"},
    ne: {kind: "solid", color: "green"},
    sw: {kind: "solid", color: "blue"},
    se: {kind: "solid", color: "white"}},
    ne: {kind: "solid", color: "green"},
    sw: {kind: "solid", color: "blue"},
    se: {kind: "split", 
    nw: {kind: "solid", color: "red"},
    ne: {kind: "solid", color: "green"},
    sw: {kind: "solid", color: "blue"}, 
    se: {kind: "solid", color: "white"}}});
    assert.deepStrictEqual(replace(square, replacement, path2),
    {kind: "split", 
    nw: {kind: "solid", color: "red"},
    ne: {kind: "split", 
    nw: {kind: "solid", color: "red"},
    ne: {kind: "solid", color: "green"},
    sw: {kind: "solid", color: "blue"},
    se: {kind: "solid", color: "white"}},
    sw: {kind: "solid", color: "blue"},
    se: {kind: "split", 
    nw: {kind: "solid", color: "red"},
    ne: {kind: "solid", color: "green"},
    sw: {kind: "solid", color: "blue"}, 
    se: {kind: "solid", color: "white"}}});
    assert.deepStrictEqual(replace(square, replacement, path3),
    {kind: "split", 
    nw: {kind: "solid", color: "red"},
    ne: {kind: "solid", color: "green"},
    sw: {kind: "split", 
      nw: {kind: "solid", color: "red"},
      ne: {kind: "solid", color: "green"},
      sw: {kind: "solid", color: "blue"},
      se: {kind: "solid", color: "white"}},
    se: {kind: "split", 
      nw: {kind: "solid", color: "red"},
      ne: {kind: "solid", color: "green"},
      sw: {kind: "solid", color: "blue"}, 
      se: {kind: "solid", color: "white"}}});

    assert.deepStrictEqual(replace(square, replacement, path4), square);

    // Path is of length greater than 1
    assert.deepStrictEqual(replace(square, replacement, path5),
    {kind: "split", 
    nw: {kind: "solid", color: "red"},
    ne: {kind: "solid", color: "green"},
    sw: {kind: "solid", color: "blue"},
    se: {kind: "split", 
      nw: {kind: "split", 
        nw: {kind: "solid", color: "red"},
        ne: {kind: "solid", color: "green"},
        sw: {kind: "solid", color: "blue"},
        se: {kind: "solid", color: "white"}},
      ne: {kind: "solid", color: "green"},
      sw: {kind: "solid", color: "blue"}, 
      se: {kind: "solid", color: "white"}}});
  });
});
