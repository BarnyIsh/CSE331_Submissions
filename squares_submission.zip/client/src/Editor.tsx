import React, { Component, ChangeEvent, MouseEvent } from "react";
import { Square, Path, findSquare, replace } from './square';
import { SquareElem } from "./square_draw";
import { len, prefix } from "./list";


type EditorProps = {
  /** Initial state of the file. */
  initialState: Square;

  swapForm: () => void;

  save: (curSquare: Square) => void;

  refresh: () => void;
};


type EditorState = {
  /** The root square of all squares in the design */
  root: Square;

  /** Path to the square that is currently clicked on, if any */
  selected?: Path;
};


/** UI for editing the image. */
export class Editor extends Component<EditorProps, EditorState> {

  constructor(props: EditorProps) {
    super(props);

    this.state = { root: props.initialState };
  }

  render = (): JSX.Element => {
    // TODO: add some editing tools here
    return <><SquareElem width={600n} height={600n}
                square={this.state.root} selected={this.state.selected}
                onClick={this.doSquareClick}></SquareElem>
            <div style={{ position: "static"}}>
              <h1 style={{ color: "red"}}>Tools</h1>
                <button onClick={this.doSaveClick}>Save</button>
                <button onClick={this.doCloseClick}>Close</button>
                <button onClick={this.doSplitClick}>Split</button>
                <button onClick={this.doMergeClick}>Merge</button>
                <select id = "colorSelect" onChange={this.doColorChange}>
                  <option value="white">White</option>
                  <option value="red">Red</option>
                  <option value="orange">Orange</option>
                  <option value="yellow">Yellow</option>
                  <option value="green">Green</option>
                  <option value="blue">Blue</option>
                  <option value="purple">Purple</option>
                </select>
            </div></>;
  };
  doCloseClick = (_evt: MouseEvent<HTMLButtonElement>): void => {
    this.props.swapForm();
    this.props.refresh();
  }

  doSaveClick = (_evt: MouseEvent<HTMLButtonElement>): void => {
    this.props.save(this.state.root);
  }

  doSquareClick = (path: Path): void => {
    // TODO: remove this code, do something with the path to the selected square
    this.setState({root: this.state.root, selected: path});
  }

  doSplitClick = (_evt: MouseEvent<HTMLButtonElement>): void => {
    if (this.state.selected === undefined) {
      throw new Error("This shouldnt happen I swear");
    } else {
      const splittedSquare = findSquare(this.state.root, this.state.selected);
      const newSquare: Square = {kind: "split",
      nw: splittedSquare,
      ne: splittedSquare,
      sw: splittedSquare,
      se: splittedSquare}
      this.setState({root: replace(this.state.root, newSquare, this.state.selected)});
    }
  };

  doMergeClick = (_evt: MouseEvent<HTMLButtonElement>): void => {
    if (this.state.selected === undefined) {
      throw new Error("This shouldnt happen I swear");
    } else {
      const splittedSquare = findSquare(this.state.root, this.state.selected);
      if (splittedSquare.kind === "split") {
        throw new Error("This also shouldnt happen i promise");
      } else {
        if (this.state.root.kind === "solid") {
          throw new Error("Cant merge");
        } else {
          const newSquare: Square = {kind: "solid", color: splittedSquare.color}
          this.setState({root: replace(this.state.root, newSquare, prefix(len(this.state.selected) - 1n, this.state.selected))});
        }
      }
    }
  };  

  doColorChange = (_evt: ChangeEvent<HTMLSelectElement>): void => {
    if (this.state.selected === undefined) {
      throw new Error("This shouldnt happen I swear");
    } else {
      if (!(_evt.target.value === "white" || _evt.target.value ===  "red" || 
      _evt.target.value === "orange" || _evt.target.value === "yellow" ||
      _evt.target.value === "green" || _evt.target.value ===  "blue" || 
      _evt.target.value === "purple")) {
        throw new Error("This really shouldnt happen");
      } else {
        const newSquare: Square = {kind: "solid", color: _evt.target.value};
        console.log(this.state.selected);
        this.setState({root: replace(this.state.root, newSquare, this.state.selected)});
      }
    }
  };
}
