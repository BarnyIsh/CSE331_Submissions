import React, { ChangeEvent, Component } from "react";
import { fromJson, solid, split, Square, toJson } from './square';
import { Editor } from "./Editor";
import { isRecord } from "./record";

type AppState = {
  showForm: Boolean;
  name: string;
  files: string[];
  loadScreen: Square;
};


export class App extends Component<{}, AppState> {

  constructor(props: {}) {
    super(props);

    this.state = {showForm: true, name: "", files: [], 
    loadScreen: split(solid("blue"), solid("orange"), solid("purple"), solid("red"))};
  }
  
  componentDidMount = (): void => {
    this.doRefreshClick();
  }

  render = (): JSX.Element => {
    if (this.state.showForm) {
      return (<div>
                <h1>Creating a nice Square pattern</h1>
                <label htmlFor="fname">Name: </label>
                <input type="text" id="fname" name="fname" onChange={this.doNameChange}></input>
                <input type="submit" value="create" onClick={this.doCreateClick}></input>
                <h1>Existing Files</h1>
                {this.renderFiles()}
              </div>)
    } else {
      return <Editor initialState={this.state.loadScreen} swapForm={this.doButtonClick} save={this.doSaveClick} refresh={this.doRefreshClick}/>;
    }
  };
  // Allows the user to create a new file with the default design
  doCreateClick = (): void => {
    if (!(this.state.files.find((e) => e == this.state.name) === undefined)) {
      throw new Error("Please pick a unique name :D");
    }
    this.setState({loadScreen: split(solid("blue"), solid("orange"), solid("purple"), solid("red"))});
    this.doButtonClick();
  }

  // Produces a list of files that have been saved
  renderFiles = (): JSX.Element => {
    if (this.state.files === undefined) {
      return <p>Loading file list...</p>;
    } else {
      const files: JSX.Element[] = [];
      for (const [index, file] of this.state.files.entries()) {
        files.push(
          <li key={index}>
            <a href="#" onClick={() => this.doFileClick(file)}>{file}</a>
          </li>);
      }
      return <ul>{files}</ul>;
    }
  };
  // Catches to see if there is an error in loading a file
  doLoadResp = (resp: Response): void => {
    if (resp.status === 200) {
      resp.json().then(this.doLoadJson)
          .catch(() => this.doLoadError("200 response is not JSON"));
    } else if (resp.status === 400) {
      resp.text().then(this.doLoadError)
          .catch(() => this.doLoadError("400 response is not text"));
    } else {
      this.doListError(`bad status code from /api/load: ${resp.status}`);
    }
  };
  // Loads the file that the user selects
  doLoadJson = (data: unknown): void => {
    if (!isRecord(data)) {
      console.error("bad data from /api/load: not a record", data);
      return;
    } 
    if ((data.value === undefined)) {
      console.error("bad data from/api/load: files is not an array", data.list);
      return;
    }
    this.setState({loadScreen: fromJson(data.value)});
    this.doButtonClick();
    console.log("Current Screen:");
    console.log(this.state.loadScreen);

  };
  // Throws an error if there is an issue with loading the file
  doLoadError = (msg: string): void => {
    console.error(`Error fetching /api/load: ${msg}`);
  };

  // Updates the list of saved files 
  doListJson = (data: unknown): void => {
    if (!isRecord(data)) {
      console.error("bad data from /api/list: not a record", data);
      return;
    } 
    if (!(Array.isArray(data.list))) {
      console.error("bad data from/api/list: files is not an array", data.list);
      return;
    }
    console.log(data.list);
    this.setState({files: data.list});
  };

  // THrows an error if the website could not load the list of saved files
  doListError = (msg: string): void => {
    console.error(`Error fetching /api/list: ${msg}`);
  };
  // Gets the latest list of files
  doRefreshClick = (): void => {
    fetch("/api/list").then(this.doListResp)
        .catch(() => this.doListError("failed to connect to server"));
  };
  // Throws an error if there was an issue in finding the list of files
  doListResp = (resp: Response): void => {
    if (resp.status === 200) {
      resp.json().then(this.doListJson)
          .catch(() => this.doListError("200 response is not JSON"));
    } else if (resp.status === 400) {
      resp.text().then(this.doListError)
          .catch(() => this.doListError("400 response is not text"));
    } else {
      this.doListError(`bad status code from /api/list: ${resp.status}`);
    }
  };

  // Loads the saved file that the user chose
  doFileClick = (name: string): void => {
    const args = { name: name}
    this.setState({name: name});
    fetch("/api/load/", {body: "?name=" + encodeURIComponent(args.name),
        headers: {"Content-Type": "application/json"}}).then(this.doLoadResp)
        .catch(() => this.doSaveError("failed to connect to server"));
  };



  // Stores the name the user writes for the file
  doNameChange = (event: ChangeEvent<HTMLInputElement>): void => {
    this.setState({name: event.target.value});
  }

  // Saves the file the user makes under the name
  doSaveResp = (resp: Response): void => {
    if (resp.status === 200) {
      resp.json().then(this.doSaveJson)
          .catch(() => this.doSaveError("200 response is not JSON"));
    } else if (resp.status === 400) {
      resp.text().then(this.doSaveError)
          .catch(() => this.doSaveError("400 response is not text"));
    } else {
      this.doSaveError(`bad status code from /api/save: ${resp.status}`);
    }
  };
  // Saves the file the user makes under the name
  doSaveJson = (data: unknown): void => {
    if (!isRecord(data)) {
      console.error("data is not a record");
      return;
    }
    if (!(typeof data.replaced === "boolean")) {
      console.error("bad data from /api/save: not a boolean", data);
      return;
    } else if (data.replaced) {
      console.log("Original saved file has been replaced with current file");
    } else {
      console.log("File has been save");
    }
    this.doRefreshClick;
    return;
  };
  // Catches error if there is a problem saving
  doSaveError = (msg: string): void => {
    console.error(`Error fetching /api/save: ${msg}`);
  };
  // Triggers when the save button is pressed
  doSaveClick = (curSquare: Square): void => {
    console.log("saved value: ");
    console.log(toJson(curSquare));
    const args = { name: this.state.name, value: toJson(curSquare)}
    fetch("/api/save", {method: "POST", body: JSON.stringify(args), 
        headers: {"Content-Type": "application/json"}}).then(this.doSaveResp)
        .catch(() => this.doSaveError("failed to connect to server"));
  };



  // Shows and hides the form at the beginning (calling it buttonclick to abide by linter)
  doButtonClick = (): void => {
    this.setState({showForm: !this.state.showForm});
  };

}
