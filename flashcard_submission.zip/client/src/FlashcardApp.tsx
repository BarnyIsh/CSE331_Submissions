import React, { Component } from "react";
import { isRecord } from "./record";
import "./style.css"
import { DeckEditor } from "./DeckEditor";
import { QuizTaker } from "./QuizTaker";
import { Deck } from "./Deck";



type FlashcardAppState = {
  // Allows user to see different pages of the site.
  showDeckList: boolean;
  createNewDeck: boolean;
  finishedStudying: boolean;
  showScoresList: boolean;

  decks: string[];
  scores: string[]
  deckName: string;
  loadedDeck: Deck;
}


/** Displays the UI of the Flashcard application. */
export class FlashcardApp extends Component<{}, FlashcardAppState> {

  constructor(props: {}) {
    super(props);

    this.state = {showDeckList: true, decks: [],
    createNewDeck: false, loadedDeck: {name: "", contents: [["", ""]]},
    deckName: "", scores: [], showScoresList: false, finishedStudying: false};
  }
    
  componentDidMount = (): void => {
    this.doRefreshClick();
  }

  render = (): JSX.Element => {
    if (this.state.showDeckList) {
      return <div>
              <h1>Your list of flashcards</h1>
              {this.renderFlashcards()}
              <button onClick={this.doCreateDeckButtonClick}>New</button>
            </div>;
    } 
    else if (this.state.createNewDeck) {
      return <DeckEditor save={this.doCreateDeckClick} back={this.doCreateDeckButtonClick}/>;
    }
    else if (!this.state.finishedStudying) {
      return <QuizTaker initialstate={[this.state.deckName, this.state.loadedDeck]}
                        submit={this.doCreateScoreClick}/>
    }
    else {
      return <div>
              <h1>Scores</h1>
              {this.renderScores()}
              <button onClick={this.doResetClick}>Return</button>
            </div>
    }
  }

  // Renders the list of already made decks
  renderFlashcards = (): JSX.Element => {
    if (this.state.showDeckList === undefined) {
      return <p>Loading deck list...</p>
    } else if (this.state.decks.length === 0) {
      return <div>Hmm... you dont have any decks. Click the new button to make a new deck!</div>
    } else {
      const decks: JSX.Element[] = [];
      for (const [index, deck] of this.state.decks.entries()) {
        decks.push(
          <li key={index}>
            <a href="#" onClick={() => this.doDeckClick(deck)}>{deck}</a>
          </li>
        )
      }
      return <ul>{decks}</ul>
    }
  }
  // Renders the list of saved scores
  renderScores = (): JSX.Element => {
    const scores: JSX.Element[] = [];
    for (const [index, score] of this.state.scores.entries()) {
      scores.push(
        <li key={index}>
          {score[0]}, {score[1]}
        </li>
      )
    }
    return <ul>{scores}</ul>
  };

  // Saves the deck the user makes under the name
  doSaveDeckResp = (resp: Response): void => {
    if (resp.status === 200) {
      resp.json().then(this.doSaveDeckJson)
          .catch(() => this.doSaveDeckError("200 response is not JSON"));
    } else if (resp.status === 400) {
      resp.text().then(this.doSaveDeckError)
          .catch(() => this.doSaveDeckError("400 response is not text"));
    } else {
      this.doSaveDeckError(`bad status code from /api/saveDeck: ${resp.status}`);
    }
  };
  // Saves the deck the user makes under the name
  doSaveDeckJson = (data: unknown): void => {
    if (!isRecord(data)) {
      console.error("data is not a record");
      return;
    }
    if (!(typeof data.replaced === "boolean")) {
      console.error("bad data from /api/saveDeck: not a boolean", data);
      return;
    } else if (data.replaced) {
      console.log("Original saved deck has been replaced with current deck");
    } else {
      console.log("Deck has been saved");
    }
  };
  // Catches error if there is a problem saving
  doSaveDeckError = (msg: string): void => {
    console.error(`Error fetching /api/saveDeck: ${msg}`);
  };



  // Catches to see if there is an error in loading a deck
  doLoadDeckResp = (resp: Response): void => {
    if (resp.status === 200) {
      resp.json().then(this.doLoadDeckJson)
          .catch(() => this.doLoadDeckError("200 response is not JSON"));
    } else if (resp.status === 400) {
      resp.text().then(this.doLoadDeckError)
          .catch(() => this.doLoadDeckError("400 response is not text"));
    } else {
      this.doLoadDeckError(`bad status code from /api/loadDeck: ${resp.status}`);
    }
  };
  // Loads the deck that the user selects
  doLoadDeckJson = (data: unknown): void => {
    if (!isRecord(data)) {
      console.error("bad data from /api/loadDeck: not a record", data);
      return;
    } 
    if ((data.value === undefined)) {
      console.error("bad data from/api/loadDeck: Deck is not an array", data.list);
      return;
    }
    this.setState({loadedDeck: {name: this.state.deckName, contents: this.doLoadJson(data.value)},
              showDeckList: false, createNewDeck: false});
  };
  // Throws an error if there is an issue with loading the deck
  doLoadDeckError = (msg: string): void => {
    console.error(`Error fetching /api/loadDeck: ${msg}`);
  };

  // Loads the saved deck that the user chose
  doDeckClick = (name: string): void => {
    const args = { name: name};
    this.setState({deckName: name});
    fetch("/api/loadDeck/?name=" + encodeURIComponent(args.name)).then(this.doLoadDeckResp)
      .catch(() => this.doLoadDeckError("failed to connect to server"));
  };

  // Throws an error if there was an issue in finding the list of decks
  doDeckListResp = (resp: Response): void => {
    if (resp.status === 200) {
      resp.json().then(this.doDeckListJson)
          .catch(() => this.doDeckListError("200 response is not JSON"));
    } else if (resp.status === 400) {
      resp.text().then(this.doDeckListError)
          .catch(() => this.doDeckListError("400 response is not text"));
    } else {
      this.doDeckListError(`bad status code from /api/listDecks: ${resp.status}`);
    }
  };

  // Updates the list of saved decks 
  doDeckListJson = (data: unknown): void => {
    if (!isRecord(data)) {
      console.error("bad data from /api/listDeck: not a record", data);
      return;
    } 
    if (!(Array.isArray(data.list))) {
      console.error("bad data from/api/listDeck: Deck is not an array", data.list);
      return;
    }
    this.setState({decks: data.list});
  };
  // Throws an error if the website could not load the list of saved decks
  doDeckListError = (msg: string): void => {
    console.error(`Error fetching /api/listDecks: ${msg}`);
  };
  // Creates a score to retain. 
  doCreateScoreClick = (name: string, correct: number, incorrect: number): void => {

    const args = { name: name, value: this.state.deckName + ": " 
    + BigInt((100 * correct / (correct + incorrect)) - (100 * correct / (correct + incorrect)) % 1)}
    fetch("/api/saveScore", {method: "POST", body: JSON.stringify(args), 
        headers: {"Content-Type": "application/json"}}).then(this.doSaveScoreResp)
        .catch(() => this.doSaveScoreError("failed to connect to server"));
  };
  // Checks for errors and saves under given name
  doSaveScoreResp = (resp: Response): void => {
    if (resp.status === 200) {
      resp.json().then(this.doSaveScoreJson)
          .catch(() => this.doSaveScoreError("200 response is not JSON"));
    } else if (resp.status === 400) {
      resp.text().then(this.doSaveScoreError)
          .catch(() => this.doSaveScoreError("400 response is not text"));
    } else {
      this.doSaveScoreError(`bad status code from /api/saveScore: ${resp.status}`);
    }
  };
  // Ensures that the score has been saved
  doSaveScoreJson = (data: unknown): void => {
    if (!isRecord(data)) {
      console.error("data is not a record");
      return;
    }
    if (typeof data.saved === "boolean") {
      console.log("Score has been save");
      this.doRefreshScoresClick();
      return;
    } else {
      console.error("bad data from /api/saveScore: not a boolean", data);
      return;
    }
  };
  // Catches error if there is a problem saving
  doSaveScoreError = (msg: string): void => {
    console.error(`Error fetching /api/saveScore: ${msg}`);
  };
  // Throws an error if the name is empty
  doNameChangeError = (): void => {
    console.error("Name must not be empty!");
  };
  // Stores the data of the new deck for further use
  doCreateDeckButtonClick = (): void => {
    if (!this.state.showDeckList) {
      this.doRefreshClick();
    } 
    this.setState({createNewDeck: !this.state.createNewDeck, showDeckList: !this.state.showDeckList});
  };
  // Allows the user to create a new deck with the default design
  doCreateDeckClick = (name: string, deckInString: string): boolean => {
    if (name === "") {
      this.doNameChangeError();
      return false;
    } else {
      const args = { name: name, value: deckInString}
      fetch("/api/saveDeck", {method: "POST", body: JSON.stringify(args), 
          headers: {"Content-Type": "application/json"}}).then(this.doSaveDeckResp)
          .catch(() => this.doSaveDeckError("failed to connect to server"));
      return true;
    }
  };
  // Shows all previous scores in a list, checking for errors
  doScoreListResp = (resp: Response): void => {
    if (resp.status === 200) {
      resp.json().then(this.doScoreListJson)
          .catch(() => this.doScoreListError("200 response is not JSON"));
    } else if (resp.status === 400) {
      resp.text().then(this.doScoreListError)
          .catch(() => this.doScoreListError("400 response is not text"));
    } else {
      this.doScoreListError(`bad status code from /api/Scorelist: ${resp.status}`);
    }
  };
  // Updates the list of saved scores:
  doScoreListJson = (data: unknown): void => {
    if (!isRecord(data)) {
      console.error("bad data from /api/listScores: not a record", data);
      return;
    } 
    if (!(Array.isArray(data.list))) {
      console.error("bad data from/api/listScores: scores is not an array", data.list);
      return;
    }
    this.setState({scores: data.list, showScoresList: true, finishedStudying: true});
  };
  // Throws an error if the website could not load the list of saved scores
  doScoreListError = (msg: string): void => {
    console.error(`Error fetching /api/listScore: ${msg}`);
  };
  // Ensures that the data is readable in the FlashCardApp
  doLoadJson = (data: unknown): string[][] => {
    if (Array.isArray(data)) {
      if (Array.isArray(data[0])) {
        return data;
      } else {
        throw new Error("Data is an array but is not a 2d array");
      }
    } else {
      throw new Error("Data is not an array");
    }
  };

  // Gets the latest list of decks
  doRefreshClick = (): void => {
    fetch("/api/listDecks").then(this.doDeckListResp)
        .catch(() => this.doDeckListError("failed to connect to server"));
  };
  // Gets the lastest list of scores
  doRefreshScoresClick = (): void => {
    fetch("/api/listScores").then(this.doScoreListResp)
        .catch(() => this.doDeckListError("failed to connect to server"));  

  };
  // Resets everything so user can be at homepage
  doResetClick = (): void => {
    this.setState({showDeckList: true, deckName: "",
    createNewDeck: false, loadedDeck: {name: "", contents: [["", ""]]}, 
    showScoresList: false, finishedStudying: false});
  };
}