import React, { ChangeEvent, Component } from "react";

type DeckEditorProps = {
    save: (deckName: string, deckInStringForm: string) => boolean;
    back: () => void;
};

type DeckEditorState = {

    deckName: string;
    saved: boolean;
    deckInStringForm: string;

};

// UI for editing decks
export class DeckEditor extends Component<DeckEditorProps, DeckEditorState> {

    constructor(props: DeckEditorProps) {
      super(props);
  
      this.state = {saved: false, deckName: "", deckInStringForm: ""};
    }

    render = (): JSX.Element => {
        return <><div>
                    <h1>Create your new deck</h1>
                    <label htmlFor="fname">Name: </label>
                    <input type="text" id="fname" onChange={this.doDeckNameChange}></input>
                    <p>Flashcards: One per line, formatted as front|back</p>
                    <div>
                        <label htmlFor="deckCreation">Enter text:</label>
                        <br/>
                        <textarea id="deckCreation" rows={3} cols={40}
                        onChange={e => this.doDeckChange(e.target.value)}></textarea>
                    </div>
                    <button onClick={this.doCreateDeckClick}>Submit</button>
                    <button onClick={this.doCreateDeckButtonClick}>Back</button>
                    {this.doSuccessfulSubmitClick()}
      </div></>
    }
    doSuccessfulSubmitClick = (): JSX.Element | null => {
        if (this.state.saved){ 
          return <div>Deck: {this.state.deckName} has been saved, if you formatted correctly. Click "Back" to see if your deck appears!</div>
        }
        else {
          return <div></div>;
        }
    };
    // Is called whenever the name changes so we can update the current name
    doDeckNameChange = (event: ChangeEvent<HTMLInputElement>): void => {
        this.setState({deckName: event.target.value, saved: false});
    };

    // Stores the deck in string form
    doDeckChange = (event: string): void => {
        this.setState({deckInStringForm: event, saved: false});
    };
    // Saves the current deck
    doCreateDeckClick = (): void => {
        this.setState({saved: this.props.save(this.state.deckName, this.state.deckInStringForm)});
    }
    // Sends user back to list of decks
    doCreateDeckButtonClick = (): void => {
        this.props.back();
    }

}