import React, { ChangeEvent, Component } from "react";
import { Deck } from "./Deck";

type QuizTakerProps = {
    initialstate: [string, Deck];
    submit: (name: string, correct: number, incorrect: number) => void;
};

type QuizTakerState = {
    deckName: string;
    loadedDeck: Deck;

    studentName: string;

    showScoresList: boolean
    flipped: boolean;
    correct: number;
    incorrect: number;
    curCard: number;


};

// UI for studying with flashcards
export class QuizTaker extends Component<QuizTakerProps, QuizTakerState> {
    constructor(props: QuizTakerProps) {
        super(props);
        const temp = this.props.initialstate;
        this.state = {deckName: temp[0], loadedDeck: temp[1], flipped: false, studentName: "",
                        correct: 0, incorrect: 0, curCard: 0, showScoresList: false};
    }

    render = (): JSX.Element => {
        if (!this.state.showScoresList) {
            return <><div>
                        <h1>{this.state.deckName}</h1>
                        <h2>Correct: {this.state.correct} | Incorrect: {this.state.incorrect}</h2>
                        <div>
                            <div className={"card"}>
                                <div>{this.state.loadedDeck.contents[this.state.curCard][Number(this.state.flipped)]}</div>
                            </div>
                            <button onClick={this.doFlipClick}>Flip</button>
                            <button onClick={this.doCorrectClick}>Correct</button>
                            <button onClick={this.doIncorrectClick}>Incorrect</button>
                        </div>
                    </div></>
        }
        else {
            return <div>
                    <h1>{this.state.deckName}</h1>
                    <h2>Correct: {this.state.correct} | Incorrect: {this.state.incorrect}</h2>
                    <p>End of quiz</p>
                    <label htmlFor="sname">Name: </label>
                    <input type="text" id="sname" onChange={this.doStudentNameChange}></input>
                    <button onClick={this.doCreateScoreClick}>Submit</button>
                    </div>
            } 

    };

    // Flips the card from definition to term, vice verse and moves onto the next card
    doFlipClick = (): void => {
        if (this.state.flipped === true) {
        this.setState({flipped: false});
        } else {
        this.setState({flipped: true});
        }
    };

    // Increases the correct counter for user by one and moves onto the next card
    doCorrectClick = (): void => {
        this.setState({correct: this.state.correct + 1, curCard: this.state.curCard + 1,
        flipped: false});
        this.doFinishStudyingClick();
    };
    // Increases the incorrect counter for user by one
    doIncorrectClick = (): void => {
        this.setState({incorrect: this.state.incorrect + 1, curCard: this.state.curCard + 1,
        flipped: false});
        this.doFinishStudyingClick();
    };
    // Changes the page to a form that records the student's score
    doFinishStudyingClick = (): void => {
        if (this.state.loadedDeck.contents.length - 1 === this.state.curCard) {
        this.setState({showScoresList: true});
        }
    };
    // Allows us to assign a name to the study session that was taken
    doStudentNameChange = (event: ChangeEvent<HTMLInputElement>): void => {
        this.setState({studentName: event.target.value});
    };
    // Sends score information back to main page
    doCreateScoreClick = (): void => {
        this.props.submit(this.state.studentName, this.state.correct, this.state.incorrect);
    };
}