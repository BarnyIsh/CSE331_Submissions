// The structure for what a deck should look like
export type Deck = {readonly name: string, readonly contents: string[][]};