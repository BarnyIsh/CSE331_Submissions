import * as assert from 'assert';
import * as httpMocks from 'node-mocks-http';
import { listDecks, listScores, loadDeck, resetDecksForTesting, resetScoresForTesting, saveDeck, saveScore } from './routes';


describe('routes', function() {

  it('saveDeck', function() {
    // First branch, straight line code, error case (only one possible input)
    const req1 = httpMocks.createRequest(
        {method: 'POST', url: '/saveDeck', body: {value: "some stuff"}});
    const res1 = httpMocks.createResponse();
    saveDeck(req1, res1);

    assert.strictEqual(res1._getStatusCode(), 400);
    assert.deepStrictEqual(res1._getData(),
        'required argument "name" was missing');

    // Second branch, straight line code, error case (only one possible input)
    const req2 = httpMocks.createRequest(
        {method: 'POST', url: '/saveDeck', body: {name: "A"}});
    const res2 = httpMocks.createResponse();
    saveDeck(req2, res2);

    assert.strictEqual(res2._getStatusCode(), 400);
    assert.deepStrictEqual(res2._getData(),
        'required argument "value" was missing or incorrect');

    // Third branch, straight line code

    const req3 = httpMocks.createRequest({method: 'POST', url: '/saveDeck',
        body: {name: "A", value: "some stuff"}});
    const res3 = httpMocks.createResponse();
    saveDeck(req3, res3);

    assert.strictEqual(res2._getStatusCode(), 400);
    assert.deepStrictEqual(res2._getData(),
        'required argument "value" was missing or incorrect');

    const req4 = httpMocks.createRequest({method: 'POST', url: '/saveDeck',
        body: {name: "A", value: "somestuff|differentstuff\nsomemorestuff|somedifferentstuff"}});
    const res4 = httpMocks.createResponse();
    saveDeck(req4, res4);

    assert.strictEqual(res4._getStatusCode(), 200);
    assert.deepStrictEqual(res4._getData(), {replaced: true});

    // Called to clear all saved decks created in this test
    //    to not effect future tests
    resetDecksForTesting();
  });


  it('saveScore', function() {
    // First branch, straight line code, error case (only one possible input)
    const req1 = httpMocks.createRequest(
        {method: 'POST', url: '/saveScore', body: {value: 1324}});
    const res1 = httpMocks.createResponse();
    saveScore(req1, res1);

    assert.strictEqual(res1._getStatusCode(), 400);
    assert.deepStrictEqual(res1._getData(),
        'required argument "name" was missing');

    // Second branch, straight line code, error case (only one possible input)
    const req2 = httpMocks.createRequest(
        {method: 'POST', url: '/saveScore', body: {name: "A"}});
    const res2 = httpMocks.createResponse();
    saveScore(req2, res2);

    assert.strictEqual(res2._getStatusCode(), 400);
    assert.deepStrictEqual(res2._getData(),
        'required argument "value" was missing');

    // Third branch, straight line code

    const req3 = httpMocks.createRequest({method: 'POST', url: '/saveScore',
        body: {name: "A", value: 43}});
    const res3 = httpMocks.createResponse();
    saveScore(req3, res3);

    assert.strictEqual(res3._getStatusCode(), 200);
    assert.deepStrictEqual(res3._getData(), {saved: true});

    const req4 = httpMocks.createRequest({method: 'POST', url: '/saveScore',
        body: {name: "A", value: 12}});
    const res4 = httpMocks.createResponse();
    saveScore(req4, res4);

    assert.strictEqual(res4._getStatusCode(), 200);
    assert.deepStrictEqual(res4._getData(), {saved: true});

    // Third branch, straight line code. Duplicate save request should be true

    const req5 = httpMocks.createRequest({method: 'POST', url: '/saveScore',
        body: {name: "A", value: 12}});
    const res5 = httpMocks.createResponse();
    saveScore(req5, res5);

    assert.strictEqual(res5._getStatusCode(), 200);
    assert.deepStrictEqual(res5._getData(), {saved: true});

    // Called to clear all saved Scores created in this test
    //    to not effect future tests
    resetScoresForTesting();
  });


  it('loadDeck', function() {

    // Requested data is in the deck
    // First need to save something in order to load it
    const saveReq = httpMocks.createRequest({method: 'POST', url: '/saveDeck',
        body: {name: "a", value: "term|def\nnewterm|newdef"}});
    const saveResp = httpMocks.createResponse();
    saveDeck(saveReq, saveResp);
    // Now we can actually (mock a) request to load the deck
    const loadReq = httpMocks.createRequest(
        {method: 'GET', url: '/loadDeck', query: {name: "a"}});
    const loadRes = httpMocks.createResponse();
    loadDeck(loadReq, loadRes);
    // Validate that both the status code and the output is as expected
    assert.strictEqual(loadRes._getStatusCode(), 200);
    assert.deepStrictEqual(loadRes._getData(), {value: [["term", "def"], ["newterm", "newdef"]]});

    // First need to save something in order to load it
    const saveReq1 = httpMocks.createRequest({method: 'POST', url: '/saveDeck',
        body: {name: "b", value: "term|def"}});
    const saveResp1 = httpMocks.createResponse();
    saveDeck(saveReq1, saveResp1);
    // Now we can actually (mock a) request to load the deck
    const loadReq1 = httpMocks.createRequest(
        {method: 'GET', url: '/loadDeck', query: {name: "b"}});
    const loadRes1 = httpMocks.createResponse();
    loadDeck(loadReq1, loadRes1);
    // Validate that both the status code and the output is as expected
    assert.strictEqual(loadRes1._getStatusCode(), 200);
    assert.deepStrictEqual(loadRes1._getData(), {value: [["term", "def"]]});


    // Requested data is not in the deck
    // First need to save something in order to load it
    const saveReq2 = httpMocks.createRequest({method: 'POST', url: '/saveDeck',
        body: {name: "keystone", value: "file value"}});
    const saveResp2 = httpMocks.createResponse();
    saveDeck(saveReq2, saveResp2);
    // Now we can actually (mock a) request to load the deck
    const loadReq2 = httpMocks.createRequest(
        {method: 'GET', url: '/loadDeck', query: {name: "c"}});
    const loadRes2 = httpMocks.createResponse();
    loadDeck(loadReq2, loadRes2);
    // Validate that both the status code and the output is as expected
    assert.strictEqual(loadRes2._getStatusCode(), 404);
    assert.deepStrictEqual(loadRes2._getData(), 'deck lacks inputted "name"');

    // First need to save something in order to load it
    const saveReq3 = httpMocks.createRequest({method: 'POST', url: '/saveDeck',
        body: {name: "Conrad", value: "Is a cool guy"}});
    const saveResp3 = httpMocks.createResponse();
    saveDeck(saveReq3, saveResp3);
    // Now we can actually (mock a) request to load the deck
    const loadReq3 = httpMocks.createRequest(
        {method: 'GET', url: '/loadDeck', query: {name: "d"}});
    const loadRes3 = httpMocks.createResponse();
    loadDeck(loadReq3, loadRes3);
    // Validate that both the status code and the output is as expected
    assert.strictEqual(loadRes3._getStatusCode(), 404);
    assert.deepStrictEqual(loadRes3._getData(), 'deck lacks inputted "name"');

    // No data was requested -> type was undefined
    // First need to save something in order to load it
    const saveReq4 = httpMocks.createRequest({method: 'POST', url: '/saveDeck',
        body: {name: "false", value: "file value"}});
    const saveResp4 = httpMocks.createResponse();
    saveDeck(saveReq4, saveResp4);
    // Now we can actually (mock a) request to load the deck
    const loadReq4 = httpMocks.createRequest(
        {method: 'GET', url: '/loadDeck', query: {}});
    const loadRes4 = httpMocks.createResponse();
    loadDeck(loadReq4, loadRes4);
    // Validate that both the status code and the output is as expected
    assert.strictEqual(loadRes4._getStatusCode(), 400);
    assert.deepStrictEqual(loadRes4._getData(), 'Required argument "name" was missing');

    resetDecksForTesting();
  });

  it('listScores', function() {
    // Making a request without anything in the list
    const listreq = httpMocks.createRequest();
    const listresp = httpMocks.createResponse();
    listScores(listreq, listresp);
    // Validate that both the status code and the output is as expected
    assert.strictEqual(listresp._getStatusCode(), 200);
    assert.deepStrictEqual(listresp._getData(), {list: []});

    // Requested data is in the array
    // First need to save something in order to load it
    const saveReq1 = httpMocks.createRequest({method: 'POST', url: '/saveScore',
        body: {name: "a", value: 12}});
    const saveResp1 = httpMocks.createResponse();
    saveScore(saveReq1, saveResp1);
    // Now we can actually (mock a) request to load the array
    const listreq1 = httpMocks.createRequest();
    const listresp1 = httpMocks.createResponse();
    listScores(listreq1, listresp1);
    // Validate that both the status code and the output is as expected
    assert.strictEqual(listresp1._getStatusCode(), 200);
    assert.deepStrictEqual(listresp1._getData(), {list: [["a", 12]]});
    
    resetScoresForTesting();

    // Requested data is in the array
    // First need to save something in order to load it
    const saveReq2 = httpMocks.createRequest({method: 'POST', url: '/saveScore',
        body: {name: "a", value: 1}});
    const saveResp2 = httpMocks.createResponse();
    saveScore(saveReq2, saveResp2);

    const saveReq3 = httpMocks.createRequest({method: 'POST', url: '/saveScore',
        body: {name: "b", value: 2}});
    const saveResp3 = httpMocks.createResponse();
    saveScore(saveReq3, saveResp3);

    // Now we can actually (mock a) request to load the array
    const listreq2 = httpMocks.createRequest();
    const listresp2 = httpMocks.createResponse();
    listScores(listreq2, listresp2);
    // Validate that both the status code and the output is as expected
    assert.strictEqual(listresp2._getStatusCode(), 200);
    assert.deepStrictEqual(listresp2._getData(), {list: [["a", 1], ["b", 2]]});
    
    resetScoresForTesting(); 
  });
  it('listDecks', function() {
    // Making a request without anything in the file
    const listreq = httpMocks.createRequest();
    const listresp = httpMocks.createResponse();
    listDecks(listreq, listresp);
    // Validate that both the status code and the output is as expected
    assert.strictEqual(listresp._getStatusCode(), 200);
    assert.deepStrictEqual(listresp._getData(), {list: []});

    // Requested data is in the file
    // First need to save something in order to load it
    const saveReq1 = httpMocks.createRequest({method: 'POST', url: '/saveDeck',
        body: {name: "a", value: "file value"}});
    const saveResp1 = httpMocks.createResponse();
    saveDeck(saveReq1, saveResp1);
    // Now we can actually (mock a) request to load the file
    const listreq1 = httpMocks.createRequest();
    const listresp1 = httpMocks.createResponse();
    listDecks(listreq1, listresp1);
    // Validate that both the status code and the output is as expected
    assert.strictEqual(listresp1._getStatusCode(), 200);
    assert.deepStrictEqual(listresp1._getData(), {list: ["a"]});
    
    resetDecksForTesting();

    // Requested data is in the file
    // First need to save something in order to load it
    const saveReq2 = httpMocks.createRequest({method: 'POST', url: '/saveDeck',
        body: {name: "a", value: "adf|asdf"}});
    const saveResp2 = httpMocks.createResponse();
    saveDeck(saveReq2, saveResp2);

    const saveReq3 = httpMocks.createRequest({method: 'POST', url: '/saveDeck',
        body: {name: "b", value: "afdas|vcas"}});
    const saveResp3 = httpMocks.createResponse();
    saveDeck(saveReq3, saveResp3);

    // Now we can actually (mock a) request to load the file
    const listreq2 = httpMocks.createRequest();
    const listresp2 = httpMocks.createResponse();
    listDecks(listreq2, listresp2);
    // Validate that both the status code and the output is as expected
    assert.strictEqual(listresp2._getStatusCode(), 200);
    assert.deepStrictEqual(listresp2._getData(), {list: ["a", "b"]});
    
    resetDecksForTesting(); 
});
});
