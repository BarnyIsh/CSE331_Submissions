import { Request, Response } from "express";
import { ParamsDictionary } from "express-serve-static-core";


// Require type checking of request body.
type SafeRequest = Request<ParamsDictionary, {}, Record<string, unknown>>;
type SafeResponse = Response;  // only writing, so no need to check

/**
 * Keeps track of the saved decks via their name and content
 */
const decks: Map<string, unknown> = new Map<string, unknown>();
var scores: [string, unknown][] = [];


/** Handles request for /saveDeck by storing the given deck. */
export const saveDeck = (req: SafeRequest, res: SafeResponse): void => {
  const name = req.body.name;
  if (name === undefined || typeof name !== 'string') {
    res.status(400).send('required argument "name" was missing');
    return;
  }
  const value = req.body.value;
  var processedValue: string[][] = [];
  if (value === undefined || typeof value !== 'string' || typeof value === null || value.length === 0) {
    res.status(400).send('required argument "value" was missing or incorrect');
    return;
  }
  var eachCard = [];
  for (const card of value.split('\n')) {
    eachCard = card.split('|');
    if (eachCard.length !== 2) {
      res.status(400).send('Format of "value" is incorrect');
    } else {
      processedValue.push(eachCard);
    }
  }
  
  res.send({replaced: decks.has(name)});
  decks.set(name, processedValue);
};

/** Handles request for /saveScore by storing the given deck. */
export const saveScore = (req: SafeRequest, res: SafeResponse): void => {
  const name = req.body.name;
  if (name === undefined || typeof name !== 'string') {
    res.status(400).send('required argument "name" was missing');
    return;
  }

  const value = req.body.value;
  if (value === undefined) {
    res.status(400).send('required argument "value" was missing');
    return;
  }
  
  scores.push([name, value]);
  res.send({saved: true});
};


/** Handles request for /loadDeck by returning the deck requested. */
export const loadDeck = (req: SafeRequest, res: SafeResponse): void => {
  const name = first(req.query.name);
  if (name === undefined) {
    res.status(400).send('Required argument "name" was missing');
    return;
  } else if (!decks.has(name)) {
    res.status(404).send('deck lacks inputted "name"');
    return;
  } else {
    res.send({value: decks.get(name)});
  }
};

/** Handles request for /listScores by returning the names of all decks currently saved */
export const listScores = (_req: SafeRequest, res: SafeResponse): void => {
  res.send({list: scores});
}

/** Handles request for /listScores by returning the names of all decks currently saved */
export const listDecks = (_req: SafeRequest, res: SafeResponse): void => {
  res.send({list: Array.from(decks.keys())});
}


// Helper to return the (first) value of the parameter if any was given.
// (This is mildly annoying because the client can also give mutiple values,
// in which case, express puts them into an array.)
const first = (param: unknown): string|undefined => {
  if (Array.isArray(param)) {
    return first(param[0]);
  } else if (typeof param === 'string') {
    return param;
  } else {
    return undefined;
  }
};

/** Used in tests to set the decks map back to empty. */
export const resetDecksForTesting = (): void => {
  // Do not use this function except in tests!
  decks.clear();
};

/** Used in tests to set the scores array back to empty. */
export const resetScoresForTesting = (): void => {
  // Do not use this function except in tests!
  scores = [];
};
