import express, { Express } from "express";
import bodyParser from 'body-parser';
import { listDecks, listScores, loadDeck, saveDeck, saveScore } from "./routes";


// Configure and start the HTTP server.
const port: number = 8088;
const app: Express = express();
app.use(bodyParser.json());
app.get("/api/loadDeck", loadDeck);
app.get("/api/listScores", listScores);
app.get("/api/listDecks", listDecks);
app.post("/api/saveDeck", saveDeck);
app.post("/api/saveScore", saveScore);
app.listen(port, () => console.log(`Server listening on ${port}`));
